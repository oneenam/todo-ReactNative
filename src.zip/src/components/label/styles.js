/**
 * Created by Muhammad Enamul Huq Sarkar on 3/31/18
 */

import { StyleSheet } from 'react-native';

export default StyleSheet.create({
    textStyle: {
        color: 'black',
        fontSize: 30,
        fontFamily: 'verdana',
        fontWeight: 'bold',
    }
});