/**
 * Created by Muhammad Enamul Huq Sarkar on 3/31/18
 */

import navigation from './navigatorReducer';
import auth from './authReducer';
import todo from './todoReducer';
export default { navigation, auth, todo };