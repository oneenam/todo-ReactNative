/**
 * Created by Muhammad Enamul Huq Sarkar on 3/31/18
 */

import React, { Component } from 'react'
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { View, Platform, TouchableOpacity, Text, FlatList, ScrollView } from "react-native";
import { NavigationActions } from 'react-navigation'
import Label from '../../../components/label';
import styles from './styles';

class TodoListContainer extends Component {

    constructor(props) {
        super(props)
        this.state = {
            stickyHeaderIndices: [],
            dataSource: []
        };
    }

    componentWillMount() {
        this.populateList(this.props.todos);
    }

    componentDidMount() {
    }

    componentWillReceiveProps(nextProps) {
    }

    shouldComponentUpdate(nextProps, nextState) {
        return true;
    }

    componentWillUpdate(nextProps, nextState) {
    }

    componentDidUpdate(prevProps, prevState) {
    }

    componentWillUnmount() {
    }

    handleAddItem = () => {
        this.props.navigation.dispatch(NavigationActions.reset(
            {
                index: 0,
                actions: [NavigationActions.navigate({ routeName: 'TodoAdd', params: { addItem: true } })]
            }
        ));
    }


    populateList = (data) => {
        var arr = [];

        data.map(obj => {

            if (obj.createdAt) {
                arr.push({ createdAt: obj.createdAt });
            }
            if (obj.todos) {
                obj.todos.map(o => {
                    arr.push(o);
                });

            }
            //arr.push(data.indexOf(obj));

        });
        //console.log(arr);
        this.setState({ dataSource: arr });

    }
    handleTodoComplete = (item) => {
        console.log("ok");
    }
    _renderItem = ({ item }) => {
        if (item.text) {
            return (
                <View style={{ marginLeft: 20, marginRight: 20, marginTop: 10, marginBottom: 10, flexDirection: 'column', }}>
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                        {
                            (item.completed) ?
                                <TouchableOpacity onPress={this.handleTodoComplete(item)}>
                                    <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: 'black' }} />
                                </TouchableOpacity>
                                :

                                <View style={{ width: 12, height: 12, borderRadius: 6, borderColor: '#C0C0C0', borderWidth: 1 }} />

                        }

                        <Text style={{ marginLeft: 20, flex: 1, fontFamily: 'verdana', fontSize: 18, color: 'black', textDecorationLine: (item.completed) ? "line-through" : "none" }}>
                            {item.text}
                        </Text>
                        <Text style={{ width: 32, height: 32, textAlignVertical: 'center', textAlign: 'center', fontFamily: 'verdana', fontSize: 18, color: 'black' }}>
                            X
                        </Text>

                    </View>
                    <View style={{ marginLeft: 30, marginTop: 20, backgroundColor: '#C0C0C0', height: 1 }} />
                </View>
            );
        } else {
            return (
                <Text style={{ marginLeft: 20, marginRight: 20, fontFamily: 'verdana', fontSize: 18, color: 'gray' }}>{item.createdAt}</Text>
            );
        }
    };

    render() {
        return (
            <View style={styles.container}>
                <View style={styles.headerContainer}>
                    <Label title="todo" />
                    <View style={styles.headerButtonStyle}>
                        <View style={styles.lineStylel} />
                        <TouchableOpacity onPress={this.handleAddItem} style={{ marginRight: 30 }}>
                            <View style={styles.addItemButton}>
                                <Text style={[{ fontSize: 18, color: 'white' }]}>
                                    +
                                </Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                </View>
{/*
                <ScrollView>
                    <View>
                        {
                            (this.state.dataSource)
                            &&
                            this.state.dataSource.map(obj => {
                                this._renderItem(obj);
                            })
                        }
                    </View>
                </ScrollView>
*/}                
                <FlatList
                    data={this.state.dataSource}
                    renderItem={this._renderItem}
                    keyExtractor={(item, index) => index.toString()}
                />



            </View>
        )
    }
}

const mapStateToProps = (state) => ({
    isLoading: state.todo.isLoading,
    error: state.todo.error,
    todos: state.todo.todos
});

const mapDispatchToProps = (dispatch) => ({
    /*loginAction: (params) => dispatch(serviceLogin(params)),
    registrationAction: (params) => dispatch(serviceRegistration(params)),
    resetAuth: () => dispatch(resetAuthService())*/
});

export default connect(mapStateToProps, mapDispatchToProps)(TodoListContainer);
